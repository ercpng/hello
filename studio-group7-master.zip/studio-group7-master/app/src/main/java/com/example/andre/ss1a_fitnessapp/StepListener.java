package com.example.andre.ss1a_fitnessapp;

/**
 * Created by davidosburn on 24/5/18.
 */

public interface StepListener {

    public void step(long timeNs);

}
