# studio-group7
# tutor: mbarbar
# students: dosburn, ephung, apagala, jwang, rmarte
#
# Hello, Students learning GitHub!
# How to git
# 
# // SET UP
# //this initizatises the repository in your android studio 
# -> git init
# //this adds all the files in your folder
# -> git add .
# //this adds a description to your commit
# -> git commit -m "hello world"
# //this adds the remote
# -> git remote add origin https://github.com/mbarbar/studio-group7.git
# //this pushes the the commit
# -> git push origin master
# //(optional) if you don't want to merge files make your own branch
# -> git push origin (branch-name)
# //example
# ->git push origin andre
#
# // EXISITING REPO
# //how to clone git repo
# -> git clone
# //how to pull
# -> git pull remote branch
# //example
# -> git pull origin master
# //pulling from from my remote and pushing to a branch named andre
# -> git pull ss1a andre
